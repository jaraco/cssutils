__author__ = '$LastChangedBy: cthedot $'
__date__ = '$LastChangedDate: 2007-06-09 21:37:11 +0200 (Sa, 09 Jun 2007) $'
__version__ = '0.7a1, SVN revision $LastChangedRevision: 25 $'
from encutils import *