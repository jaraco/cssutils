__author__ = '$LastChangedBy: cthedot $'
__date__ = '$LastChangedDate: 2007-06-09 23:04:23 +0200 (Sa, 09 Jun 2007) $'
__version__ = '0.4, SVN revision $LastChangedRevision: 29 $'

import unittest
import xml.dom

import cssutils.cssvaluelist


class CSSValueListTestCase(unittest.TestCase):

    def test_set(self):
        pass

        
if __name__ == '__main__':
    unittest.main() 