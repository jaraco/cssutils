# -*- coding: iso-8859-1 -*-
"""
testcases for cssutils.token.Token
"""
__author__ = '$LastChangedBy: cthedot $'
__date__ = '$LastChangedDate: 2007-06-09 23:04:23 +0200 (Sa, 09 Jun 2007) $'
__version__ = '0.9.2a1, SVN revision $LastChangedRevision: 29 $'

import xml.dom

import basetest

from cssutils.token import Token


class TokenTestCase(basetest.BaseTestCase):

    def test_init(self):
        "Token.init()"
        t = Token(1, 2, Token.IDENT, u'c\olor')
        self.assertEqual(1, t.line)
        self.assertEqual(2, t.col)
        self.assertEqual(Token.IDENT, t.type)
        self.assertEqual(u'c\olor', t.value)
        # self.assertEqual(u'c\olor', t.literal) # REMOVED
        self.assertEqual(u'color', t.normalvalue)


if __name__ == '__main__':
    import unittest
    unittest.main() 
