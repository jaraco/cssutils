__author__ = '$LastChangedBy: cthedot $'
__date__ = '$LastChangedDate: 2007-06-17 16:03:27 +0200 (So, 17 Jun 2007) $'
__version__ = '0.7a1, $LastChangedRevision: 61 $'
from encutils import *