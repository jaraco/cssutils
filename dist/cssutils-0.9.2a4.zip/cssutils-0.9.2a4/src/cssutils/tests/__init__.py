"""
cssutils unittests
"""
__author__ = '$LastChangedBy: cthedot $'
__date__ = '$LastChangedDate: 2007-06-17 16:04:45 +0200 (So, 17 Jun 2007) $'
__version__ = '0.9.2a1, $LastChangedRevision: 63 $'

##import unittest

##from test_tokenize import *
##from test_cssutilsimport import *
##from test_cssutils import *
##from test_serialize import *
##
##from test_csscharsetrule import *
##from test_csscomment import *
##from test_cssimportrule import *
##from test_cssrule import *
##from test_cssrulelist import *
##from test_cssstylerule import *
##from test_cssunknownrule import *
##from test_medialist import *

##testcases = (
##    TokenizerTestCase,
##    CSSutilsImportTestCase, 
##    CSSutilsTestCase,
##    CSSSerializerTestCase,
##    CSSCharsetRuleTestCase,
##    CSSCommentTestCase,    
##    CSSImportRuleTestCase,
##    CSSRuleTestCase,
##    CSSRuleListTestCase,
##    CSSStyleRuleTestCase,
##    CSSUnknownRuleTestCase,
##    MediaListTestCase
##    )

##import logging
##from cssutils import _log
##_log.setloglevel(logging.FATAL)

##suites = []
##for case in testcases:
##    suites.append(unittest.makeSuite(case))
##    
##suite = unittest.TestSuite(tuple(suites))  
##unittest.TextTestRunner(verbosity=2).run(suite)


