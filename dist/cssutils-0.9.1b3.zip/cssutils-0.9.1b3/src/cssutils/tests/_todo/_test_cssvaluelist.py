__version__ = '0.4'

import unittest
import xml.dom

import cssutils.cssvaluelist


class CSSValueListTestCase(unittest.TestCase):

    def test_set(self):
        pass

        
if __name__ == '__main__':
    unittest.main() 